# Ultra atlas (v1)

Self-contained interactive evidence atlas for Angela (2026), *Future Business Journal* 12:99.
Single file — no build step, no external assets. Served by GitHub Pages at:

    https://researchnplcrisis-cloud.github.io/gepu-bangladesh-credit-risk-dashboard/ultra1/
